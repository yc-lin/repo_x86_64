# VimShell

For information, check [doc/vimshell.txt](doc/vimshell.txt).

**Note**: Active developement on vimshell.vim has stopped. The only future changes will be bug fixes.

You should use [Deol.nvim](https://github.com/Shougo/deol.nvim) instead.

## Resources

- [Code @ HootSuite | VimShell](http://code.hootsuite.com/vimshell/)

## Screen shots

![](https://f.cloud.github.com/assets/980000/982716/eb45a994-0817-11e3-806e-ce6e731b86ef.png)
